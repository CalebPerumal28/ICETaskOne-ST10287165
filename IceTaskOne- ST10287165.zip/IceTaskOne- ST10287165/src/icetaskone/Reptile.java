/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetaskone;

import java.util.Scanner;

/**
 *
 * @author Caleb Perumal
 */
public class Reptile extends Animal {
    private double bloodTemp; 
    public double getBloodTemp() {
        return bloodTemp;
    }

    public void setBloodTemp(double bloodTemp) {
        this.bloodTemp = bloodTemp;    
        }
    
    
     public void inputOne(){
              Scanner kb = new Scanner (System.in);
      System.out.print("Enter blood temp: ");
        bloodTemp= kb.nextDouble();
        
    }
    @Override
    public void outputDisplay(){
        System.out.println("IDtag: "+ getIDtag());
    System.out.println("Species: "+ getSpecies());
        System.out.println("Blood temp: "+ bloodTemp);
    }
}
