/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetaskone;

import java.util.Scanner;

/**
 *
 * @author Caleb Perumal
 */
public class Bird extends Animal {
        Scanner kb = new Scanner (System.in);
        private int color;
    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        
        this.color = color;
    }
    
    
    
    public void inputOne(){
     System.out.println("Enter colour of bird \n"
                 + "1) Grey\n"
                 + "2) White\n"
                 + "3) Black\n"
                 + "Please enter an option");
       color= kb.nextInt();
    }
    
        @Override
     public void outputDisplay(){
        System.out.println("IDtag: "+ getIDtag());
    System.out.println("Species: "+ getSpecies());
 switch ( color){
        case   1: System.out.println("Colour: Grey");break;
        case 2: System.out.println("Colour: White");break;
        case 3: System.out.println("Colour: Black");break;
        
    }
    
     }            
}
