/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetaskone;

import java.util.Scanner;

/**
 *
 * @author Caleb Perumal
 */
public class IceTaskOne {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //this is the main 
        //the user has an option to choose from the either of the 2 types of animals
           Scanner kb = new Scanner (System.in);
           System.out.println("   Welcome to the zoo catalogue");
           System.out.println("***************************************\n");
        System.out.println("Enter 1--> Bird\n"
                + "Enter 2--> Reptile");
        int input= kb.nextInt(); 
        
        switch(input){
            case 1: birdie(); break;    // this is calling the specific method according to user choice
            case 2: repie(); break;  }
        
              
    }
    public static void birdie(){  // this is a method if 
               Scanner kb = new Scanner (System.in);
               Bird brd = new Bird();
        System.out.print("Enter ID of animal (bird): ");
         int temp= kb.nextInt();
         brd.setIDtag(temp);
         kb.nextLine();
       
  
        System.out.print("Enter species of animal(bird): ");
        String speciess= kb.nextLine(); 
        brd.setSpecies(speciess); 
        brd.inputOne();
        System.out.println(" ");
        System.out.println("Bird report:");
       brd.outputDisplay();
    }
    
      public static void repie(){
          Scanner kb = new Scanner (System.in);
          Reptile rept = new Reptile();
          
          System.out.print("Enter ID of animal (reptile): ");
         int tag= kb.nextInt();
         rept.setIDtag(tag);
         kb.nextLine();
       
  
        System.out.print("Enter species of animal(reptile): ");
        String sppecies= kb.nextLine(); 
          rept.setSpecies(sppecies);
          rept.inputOne();
          System.out.println(" ");
          System.out.println("Reptile report");
          rept.outputDisplay();
      }
    
}
